# Massarif Project Knowledge Base

Read this file before starting any task. It contains essential context about the project architecture, conventions, and current state.

## What Is Massarif

A mobile-first platform enabling diaspora members, NGOs, and donors to pay bills directly to local merchants on behalf of their loved ones in their home country. The money goes to merchants, never to individuals — that's the trust model.

- **Primary Market:** Chad (N'Djamena)
- **Diaspora Corridors:** France, Cameroon, Gulf states
- **Currency:** XAF (CFA Franc, pegged to EUR at 655.957:1)
- **Status:** MVP live on App Store and Google Play

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Mobile | Expo SDK 54, Expo Router v6, React Native 0.81 |
| Styling | NativeWind v5 (Tailwind CSS v4) — NO StyleSheet.create |
| State | Zustand v5 (client), TanStack Query v5 (server cache), Convex subscriptions (real-time) |
| Backend | Convex (DB, functions, auth, file storage, crons) |
| Payments | Stripe (cards) + Airtel Money (mobile money) |
| Push | Firebase Cloud Messaging |
| i18n | i18next + expo-localization (FR default, AR and EN planned) |
| Analytics | Firebase Crashlytics |

## Repository Structure

```
/massarif/               # Git root
  app/                   # Expo app (all frontend + convex backend)
    app/                 # Expo Router routes (file-based routing)
      _layout.tsx        # Root layout with providers
      (auth)/            # Login, register, OTP, forgot-password
      (payer)/           # Payer tabs: home, merchants, history, profile
      (merchant)/        # Merchant tabs: dashboard, invoices, profile
      payment/           # Payment flow screens
      invoice/           # Shared invoice detail
      merchant-kyc/      # 5-step KYC flow
    components/          # 56 reusable components
      ui/                # 25 base components (Button, Input, Card, Modal, etc.)
      invoice/           # InvoiceCard, InvoiceDetail, InvoiceForm
      merchant/          # MerchantCard, MerchantList
      payment/           # Payment flow components
      layout/            # ScreenWrapper, Header, TabBar, BottomActionBar
      ...                # auth, profile, beneficiary, notification, dashboard, wallet
    convex/              # Convex backend (21 function files)
      schema.ts          # 14 tables with 40+ indexes
      auth.ts            # Authentication
      users.ts           # User CRUD
      merchants.ts       # Merchant management + KYC
      invoices.ts        # Invoice lifecycle
      transactions.ts    # Payment records + fee breakdown
      fees.ts            # Dynamic fee calculation engine
      payments/stripe.ts # Stripe integration
      payments/airtelMoney.ts # Airtel Money integration
      notifications.ts   # Push/in-app notifications
      countries.ts       # Multi-country config
      crons.ts           # Background jobs
      http.ts            # Webhooks (Stripe, Airtel callbacks)
      seed.ts            # Database seeding
    hooks/               # 12 custom hooks
    stores/              # Zustand: authStore, uiStore, offlineStore, merchantKycStore
    lib/                 # Utilities: utils, i18n, firebase
    constants/           # colors, config, categories, theme
    types/               # types/index.ts — all shared types (331 lines)
    locales/             # i18n: fr.json, ar.json, en.json
  PLAN/                  # Task management for AI agent
    AGENT.md             # Agent workflow instructions
    KNOWLEDGE.md         # This file
    tasks/               # Task files (007+)
  AGENTS.md              # Code style guidelines for agents
  RULES.md               # Development rules
  CONVENTIONS.md         # Component patterns and templates
  IMPLEMENTATION_PLAN.md # Original MVP specification
  PHASE2_IMPLEMENTATION_PLAN.md  # Phase 2 full spec
  PHASE2_MEDIA_AND_CAMPAIGNS.md  # Media + Organizations addendum
  UI_CODE/               # Design system exports from Figma/design tool
```

## Existing Convex Schema (14 tables)

1. **users** — role (payer/merchant/admin), status, language, countryCode, fcmToken
2. **merchants** — kycStatus, kycDocuments, payoutMethod, payoutDetails, category, GPS
3. **beneficiaries** — phone-based passive recipients
4. **invoices** — status lifecycle: draft → pending → paid → delivered → cancelled/expired/refunded
5. **transactions** — payment records with full feeBreakdown (platform/payer/merchant fees + FX)
6. **withdrawals** — merchant payouts (Airtel/Moov/bank)
7. **countries** — multi-country config
8. **feeConfigs** — dynamic fee engine (scope: global/country/payment-method/merchant)
9. **notifications** — push/in-app notifications
10. **authTables** — Convex Auth sessions
11-14. Supporting tables (crons, etc.)

## Key Types (from types/index.ts)

- `UserRole`: payer | merchant | admin
- `InvoiceStatus`: draft | pending | paid | delivered | cancelled | expired | refunded | disputed
- `TransactionStatus`: pending | processing | completed | failed | refunded | cancelled
- `PaymentMethod`: stripe_card | airtel_money | moov_money
- `MerchantCategory`: pharmacy | grocery | telecom | healthcare | education | restaurant | ...
- `AppLanguage`: fr | ar | en

## User Roles and Navigation

- **Payer**: Accueil | Commercants | Historique | Profil
- **Merchant**: Tableau de bord | Factures | Profil
- **Admin**: Web-only (admin panel, not in mobile app)
- **Organization** (Phase 2): Tableau de bord | Campagnes | Factures | Profil

## Core Business Flow

```
Payer (diaspora) → creates invoice at Merchant → for Beneficiary (local)
Payer pays via Stripe/Airtel Money → Merchant receives notification
Merchant delivers goods → confirms delivery → Beneficiary receives goods
Payer sees delivery confirmation with optional photo proof
```

## Fee Engine

- Fees are configured per scope: global → country → payment_method → merchant (most specific wins)
- Calculation modes: percentage, fixed, percentage_plus_fixed
- Fee bearer: payer (added on top), merchant (deducted), split
- FX revenue on EUR→XAF conversions (spread on peg rate)

## Coding Conventions (Summary)

- **Styling**: NativeWind className only. Never StyleSheet.create().
- **Components**: Functional, PascalCase files, one per file, max 300 lines per screen
- **State**: Convex subscriptions for live data, Zustand for client state, never duplicate
- **Convex**: Validate inputs, check auth, use indexes, paginate lists, external APIs only in actions
- **i18n**: All user-facing strings via translation keys, never hardcode
- **Errors**: Friendly messages in Convex throws, Toast display in hooks, Crashlytics in prod
- **Imports**: React → Third-party → Convex API → Hooks/stores → Components → Constants/types

## Phase 2 New Tables (to be created)

- **media** — Polymorphic file attachments (images for invoices, merchants, campaigns)
- **organizations** — NGO/community org accounts
- **campaigns** — Public fundraising campaigns linked to merchants
- **contributions** — Donations to campaigns
- **campaignUpdates** — Progress posts by organizations
- **campaignInvoices** — Spending from campaign funds
- **recurringPayments** — Scheduled payment templates
- **splitPayments** — Crowdfunding for individual invoices
- **invoiceTemplates** — Merchant invoice shortcuts
- **favorites** — Payer merchant bookmarks
- **kycVerifications** — Admin KYC review queue
- **auditLogs** — Admin action trail
- **notificationPreferences** — Per-user notification settings
- **exchangeRates** — Currency rate cache

## Phase 2 New Features (Priority Order)

### P0 (Must Have)
1. Admin panel (Vite + React + shadcn/ui) — KYC approval, merchant/user management
2. Multi-language (FR, AR, EN) — complete Arabic with RTL, complete English
3. Beneficiary experience — SMS deep links, web status page

### P1 (High Value)
4. Media system — Photo attachments on invoices, merchants, campaigns
5. Merchant enhancements — QR codes, delivery photos, invoice templates
6. Payer enhancements — Recurring payments, favorites, receipt PDF
7. Moov Money integration — Second mobile money provider
8. Split payments — Invoice crowdfunding for families
9. Organizations & campaigns — NGO fundraising with transparent spending

### P2 (Growth)
10. Automated KYC pipeline
11. Advanced notifications (WhatsApp, preferences)
12. Fraud detection basics
13. Multi-currency engine

### P3 (Expansion)
14. Second country (Cameroon) soft launch

## Known Bugs (from NOTES.md)

- Auth step transitions need animation
- Illustrations on steps need animation
- Colors are hardcoded in places — must use theme
- Auth errors should show as modal, not inline under form
- Merchant invoice creation: back navigation broken on invoice detail screen after creation

## Important Business Rules

- Invoice expiry: 7 days
- XAF/EUR peg rate: 655.957
- KYC review must happen within 48 hours
- Recurring payments: only saved cards (not mobile money)
- Split payments expire after 14 days, minimum 1,000 FCFA
- Campaign funds go directly to merchants, never to organization accounts
- Max 10 active campaigns per organization
- Max 20 templates per merchant
- Max 50 favorites per payer

## Commands Reference

```bash
# From /massarif/app/
npx expo start                  # Dev server
npx convex dev                  # Convex dev (separate terminal)
npx expo lint                   # Lint
npx tsc --noEmit                # Type check

# From /massarif/ (git root)
git checkout -b task/007-xxx    # New task branch
```

## Before Starting Any Task

1. Read this file (KNOWLEDGE.md)
2. Read the specific task file in PLAN/tasks/
3. Read AGENTS.md for code style rules
4. Read CONVENTIONS.md for component patterns
5. Read the relevant section of PHASE2_IMPLEMENTATION_PLAN.md or PHASE2_MEDIA_AND_CAMPAIGNS.md
6. Check types/index.ts for existing types
7. Check the convex schema for existing tables
8. Build backend (Convex) first, then frontend
9. Always create types first, then hook, then component
