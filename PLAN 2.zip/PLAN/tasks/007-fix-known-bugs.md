---
id: "007"
title: "Fix known MVP bugs (animations, theme, auth errors, navigation)"
status: review
priority: urgent
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: task/007-fix-known-bugs
pr: null
attempts: 0
depends_on: []
progress: 100
---

## Description

Fix all bugs identified during Phase 1 testing before starting new Phase 2 features. These are UX issues that hurt the user experience.

### Bugs from NOTES.md:
1. **Auth step transitions need animation** — The registration/login multi-step forms have no transition animation between steps. Add smooth slide or fade transitions.
2. **Illustrations need animation** — Onboarding/auth illustrations should have subtle entrance animations (fade-in, slight scale).
3. **Hardcoded colors** — Some components have hardcoded color values instead of using the theme system from `constants/colors.ts`. Audit and fix.
4. **Auth errors display as inline text** — Should be displayed as a modal or toast, not as small text under the form field. Not user-friendly on mobile.
5. **Merchant invoice creation back navigation broken** — After a merchant creates an invoice and lands on the invoice detail screen, the back button doesn't work correctly. Should navigate back to the invoice list.

## Acceptance Criteria
- [ ] Auth multi-step forms (register, register-merchant) have smooth slide transitions between steps
- [ ] Illustrations on auth/onboarding screens have subtle entrance animations
- [ ] All hardcoded color values are replaced with theme constants
- [ ] Auth error messages display as Toast or Modal, not inline under form
- [ ] After merchant creates invoice, back navigation from invoice detail goes to invoice list
- [ ] No TypeScript errors (`npx tsc --noEmit` passes)
- [ ] No lint errors (`npx expo lint` passes)

## Context
- Auth screens: `app/app/(auth)/login.tsx`, `app/app/(auth)/register.tsx`, `app/app/(auth)/register-merchant.tsx`
- Colors: `app/constants/colors.ts`, `app/constants/theme.ts`
- Toast component: `app/components/ui/Toast.tsx`
- Invoice creation: `app/app/(merchant)/(invoices)/`
- Animation library: `react-native-reanimated` (already installed)
- NOTES.md contains the original bug reports

## Checklist
- [x] Step 1: Replace hardcoded color values in login/register/register-merchant with theme constants
- [x] Step 2: Add animated transitions for auth method/step changes (login + merchant register)
- [x] Step 3: Add subtle entrance animations to auth hero/icon sections
- [x] Step 4: Change auth general/server error handling to Toast instead of inline text
- [x] Step 5: Fix merchant invoice creation -> detail back navigation flow
- [x] Step 6: Remove remaining hardcoded colors in touched merchant invoice files
- [x] Step 7: Re-audit touched files for hardcoded color literals
- [x] Step 8: Run lint and type check, fix issues

## Review Notes

## Agent Log
### 2026-03-06
- Implemented auth UX bug fixes across login/register/register-merchant:
  - Added method/step transition animations and hero/illustration entrance animations.
  - Switched auth/server errors from inline general text to `Toast.show(...)`.
  - Replaced hardcoded colors in auth screens with `appTheme` tokens.
- Fixed merchant invoice navigation bug by passing `from=merchant-invoices` when opening invoice detail after create and handling back-navigation fallback in invoice detail header.
- Replaced remaining hardcoded colors in touched merchant invoice screens and invoice detail screen wrappers with theme constants.
- Validation:
  - `npm run -s lint` (pass, 1 pre-existing warning in login `useEffect` deps)
  - `npx tsc --noEmit` (pass)
- Push/PR commands appended to `PLAN/pending-push.sh`; awaiting manual network-enabled execution.
