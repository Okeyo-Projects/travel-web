---
id: "018"
title: "Beneficiary experience: SMS deep links and web status page"
status: review
priority: high
created: 2026-03-06
updated: 2026-03-07
assigned: codex
branch: task/018-beneficiary-experience
pr: null
attempts: 0
depends_on: []
progress: 100
---

## Description

Build the beneficiary-facing experience. Beneficiaries don't use the app — they receive SMS/WhatsApp notifications with a link to a lightweight web page showing their payment status.

### Enhanced SMS Notification:
```
Massarif: {payerName} a paye une facture de {amount} FCFA a {merchantName} pour vous.
Presentez-vous au commerce pour recuperer vos produits. Details: massarif.app/b/{code}
```

### Beneficiary Web Page (`massarif.app/b/{code}`):
- Minimal, fast-loading page (Vite static site)
- Must load on slow 2G/3G connections — minimal JS, no heavy frameworks
- Content: Massarif logo, payment confirmed message, merchant name/address/phone, description, amount, delivery status, app download link
- Multilingual (FR/AR/EN based on browser language)

### Backend:
- Generate unique beneficiary link code when invoice is paid
- HTTP endpoint to serve beneficiary page data
- Track link visits (analytics)

## Acceptance Criteria
- [ ] Unique beneficiary link code generated on invoice payment
- [ ] SMS notification includes deep link
- [ ] Web page loads in < 2 seconds on 3G
- [ ] Page shows: merchant info, amount, description, delivery status
- [ ] Page updates when delivery is confirmed
- [ ] Page works without JavaScript (server-rendered or static)
- [ ] App download links shown at bottom
- [ ] Page is multilingual (auto-detect browser language)

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Beneficiary Experience section
- SMS: `app/convex/notifications.ts` (existing Twilio integration)
- Web page: new Vite static site, could be a subpage of admin or separate tiny project
- Invoice payment flow: `app/convex/payments/stripe.ts`, `app/convex/payments/airtelMoney.ts`

## Checklist
- [x] Step 1: Add beneficiaryLinkCode field to invoices table
- [x] Step 2: Generate unique code when invoice is marked paid
- [x] Step 3: Create HTTP endpoint for beneficiary page data (convex/http.ts)
- [x] Step 4: Update SMS notification to include deep link
- [x] Step 5: Create beneficiary web page entrypoint via Convex HTTP route
- [x] Step 6: Build web page with merchant info, amount, status
- [x] Step 7: Add multilingual support (detect browser language)
- [x] Step 8: Add delivery status update (live or on refresh)
- [x] Step 9: Add app download links
- [x] Step 10: Optimize for 2G/3G (< 50KB total page weight)
- [x] Step 11: Test full flow: payment → SMS → web page → delivery update (skipped in automation: requires connected Convex deployment + payment webhook + SMS provider access)

## Review Notes

## Agent Log

### 2026-03-07 — Automation run
- Set task to `in_progress` on branch `task/018-beneficiary-experience`.
- Added beneficiary link fields/index to `invoices` schema and invoice types.
- Added unique beneficiary code generation when transactions move to `completed` and invoice becomes `paid`.
- Added internal HTTP helpers to fetch beneficiary page data and track page visits.
- Added beneficiary page endpoint at `/b/:code` plus `/b?code=` redirect fallback.
- Implemented no-JS HTML beneficiary status page with locale auto-detection (FR/EN/AR), DD/MM/YYYY date format, Latin numerals, merchant details, and app download links.
- Updated Stripe and Airtel beneficiary SMS templates to include deep link `.../b/{code}`.
- Validation run: `cd app && npx tsc --noEmit` passed; `cd app && npx expo lint` passed with one pre-existing warning in `app/(auth)/login.tsx`.
- Remaining: full external flow test (payment webhook/callback + Twilio SMS + public endpoint) requires connected Convex/Twilio environment.

### 2026-03-07 — Automation run (resume)
- Resumed task `018` from `in_progress` and re-ran local validations: `cd app && npx tsc --noEmit` passed; `cd app && npx expo lint` passed with the same pre-existing `react-hooks/exhaustive-deps` warning in `app/app/(auth)/login.tsx`.
- Attempted to run Convex CLI checks for deeper validation, but CLI calls fail in this environment because telemetry/network DNS is blocked (`getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Used Convex MCP to inspect the active own-dev deployment; it does not yet reflect this branch's beneficiary-link schema/index/HTTP changes, so external end-to-end verification for step 11 (payment → SMS → web page → delivery update) cannot be completed from this automation run.
- Task remains `in_progress` at 90% with checklist step 11 still pending until branch changes are deployed to a connected Convex environment with SMS provider credentials.

### 2026-03-07 — Automation run (resume 2)
- Confirmed branch state is clean for task code changes; only untracked workspace artifacts are `PLAN.zip` and `PLAN/REVIEWER.md`.
- Re-ran validation from the task branch: `cd app && npx tsc --noEmit` passed; `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx`.
- Retried Convex verification with telemetry disabled: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; command still fails because outbound DNS/network is unavailable (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Checklist step 11 remains blocked on connected Convex + payment/SMS provider access, so task status stays `in_progress` with `progress: 90`.

### 2026-03-07 — Automation run (resume 3)
- Re-ran local validation: `cd app && npx tsc --noEmit` passed and `cd app && npx expo lint` passed with the same pre-existing `react-hooks/exhaustive-deps` warning in `app/app/(auth)/login.tsx`.
- Retried Convex environment connectivity: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails with `Unexpected error when authorizing`, `fetch failed`, and `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`.
- Step 11 (full external flow: payment → SMS → web page → delivery update) remains blocked pending a connected Convex deployment plus reachable payment/SMS providers, so task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 4)
- Re-ran validation from the task branch: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification command for step 11: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; it still fails in this environment due outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Step 11 remains blocked on a connected Convex + payment/SMS environment, so task status stays `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 5)
- Re-read workflow and resumed task `018` from the existing unchecked Step 11 only.
- Verified branch state remains `task/018-beneficiary-experience`; workspace has unrelated untracked artifacts (`PLAN.zip`, `PLAN/REVIEWER.md`) and no new task-code diffs.
- Re-ran local checks: `cd app && npx tsc --noEmit` passed; `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Queried Convex via MCP (`status` + `functionSpec`) to attempt non-CLI end-to-end validation; active own-dev deployment still lacks beneficiary HTTP endpoints (`/b/:code`), confirming branch changes are not deployed there yet.
- Step 11 remains blocked until this branch is deployed to a reachable Convex environment with payment webhook + SMS provider connectivity, so task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 6)
- Re-read workflow and resumed task `018` from the same unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried Convex CLI connectivity for external flow testing: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails in this sandbox with outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Queried Convex own-dev deployment metadata via MCP (`status` + `functionSpec`) and confirmed it still does not expose the beneficiary HTTP route (`/b/:code`) or the new internal beneficiary-link helpers, so this branch is not deployed there for end-to-end verification.
- Step 11 remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook and Twilio SMS connectivity; task stays `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 7)
- Re-read workflow and resumed task `018` from the remaining unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification path: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails due sandbox outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Queried Convex own-dev deployment via MCP (`status` + `functionSpec`) and confirmed the remote function list still lacks beneficiary endpoint/routes from this task branch, so end-to-end payment→SMS→webpage verification cannot run there.
- Step 11 remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook + SMS provider connectivity; task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 8)
- Re-read workflow and resumed task `018` from the same remaining unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification path: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails in this sandbox due outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Step 11 (full flow payment → SMS → beneficiary web page → delivery update) remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook and SMS provider connectivity; task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 9)
- Re-read workflow and resumed task `018` from the same remaining unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification path: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails in this sandbox due outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Queried Convex own-dev deployment via MCP (`status` + `functionSpec`) and confirmed remote deployment metadata still does not include this task branch beneficiary route work (`/b/:code`), so end-to-end validation cannot run there yet.
- Step 11 remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook and SMS provider connectivity; task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 10)
- Re-read workflow and resumed task `018` from the same remaining unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification path: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails in this sandbox due outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Queried Convex own-dev deployment via MCP (`status` + `functionSpec`) and confirmed remote deployment still does not expose this branch's beneficiary route work (`/b/:code`) or related helper functions, so end-to-end validation cannot run there.
- Step 11 remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook and SMS provider connectivity; task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 11)
- Re-read workflow and resumed task `018` from the same remaining unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification path: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails in this sandbox due outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Queried Convex own-dev deployment metadata via MCP (`status` + `functionSpec`) and confirmed remote deployment still does not expose this branch's beneficiary route work (`/b/:code`) or related internal helper functions, so end-to-end validation cannot run there.
- Step 11 remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook and SMS provider connectivity; task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 12)
- Re-read workflow and resumed task `018` from the same remaining unchecked Step 11 only.
- Re-ran local validation: `cd app && npx tsc --noEmit` passed.
- Re-ran lint: `cd app && npx expo lint` passed with the same pre-existing warning in `app/app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
- Retried external verification path: `cd app && CONVEX_DISABLE_TELEMETRY=1 npx convex dev --once`; still fails in this sandbox due outbound DNS/network restrictions (`fetch failed`, `getaddrinfo ENOTFOUND o1192621.ingest.sentry.io`).
- Queried Convex own-dev deployment metadata via MCP (`status` + `functionSpec`) and confirmed remote deployment still does not expose this branch's beneficiary route work (`/b/:code`) or related internal beneficiary helpers, so end-to-end validation cannot run there.
- Step 11 remains blocked pending deployment of this branch to a reachable Convex environment with payment webhook and SMS provider connectivity; task remains `in_progress` at `progress: 90`.

### 2026-03-07 — Automation run (resume 13)
- Re-read the workflow rule for blocked steps and applied it: this external-only verification step has been retried repeatedly in a network-restricted environment.
- Marked checklist Step 11 as skipped for automation with required prerequisites noted (connected Convex deployment + payment webhook + SMS provider access).
- Updated task state to `review` with `progress: 100` so manual end-to-end validation can be completed during review in a connected environment.
- Appended manual push/PR commands to `PLAN/pending-push.sh`; awaiting manual execution in a network-enabled environment.
