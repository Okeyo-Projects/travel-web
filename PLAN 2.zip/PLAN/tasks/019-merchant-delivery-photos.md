---
id: "019"
title: "Merchant delivery photo capture on invoice confirmation"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: ["016", "017"]
progress: 0
---

## Description

When a merchant confirms delivery of an invoice, allow them to take a photo as proof of delivery. The photo is visible on the invoice detail for the payer and admin.

### Flow:
1. Merchant views paid invoice detail
2. Camera icon appears next to "Confirmer la livraison" button
3. Tapping opens camera for photo capture
4. Photo uploads to Convex file storage via media system
5. Photo appears on invoice detail for payer and admin

## Acceptance Criteria
- [ ] Camera icon on paid invoice detail (merchant view)
- [ ] Photo capture opens device camera
- [ ] Photo uploads as media with purpose "delivery_proof"
- [ ] deliveryPhotoStorageId saved on invoice record
- [ ] Photo visible on invoice detail for payer
- [ ] Photo visible on invoice detail in admin panel
- [ ] Works without photo (delivery can still be confirmed without photo)

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Invoice Detail — Add Delivery Photo
- Media system: tasks 016, 017
- Invoice detail: `app/app/invoice/[invoiceId].tsx`
- Invoice mutations: `app/convex/invoices.ts`

## Checklist
- [ ] Step 1: Add deliveryPhotoStorageId field to invoices table
- [ ] Step 2: Update invoice confirm delivery mutation to accept photo
- [ ] Step 3: Add camera capture to merchant invoice detail screen
- [ ] Step 4: Upload photo as media with purpose "delivery_proof"
- [ ] Step 5: Display delivery photo on payer invoice detail
- [ ] Step 6: Display delivery photo on admin invoice detail
- [ ] Step 7: Test flow: confirm delivery with and without photo

## Review Notes

## Agent Log
