---
id: "020"
title: "Merchant QR code generation and display"
status: review
priority: medium
created: 2026-03-06
updated: 2026-03-07
assigned: codex
branch: task/020-merchant-qr-code
pr: null
attempts: 0
depends_on: []
progress: 100
---

## Description

Generate a unique QR code for each merchant. Beneficiaries can scan it in-store to create a draft invoice linked to that merchant. Merchants can share or print their QR code.

### QR Code Content:
Deep link: `massarif://merchant/{merchantId}/create-invoice`

### Merchant Dashboard:
- "Mon QR Code" card on dashboard
- Tap → full screen QR code view
- "Partager" and "Imprimer" buttons
- Explanation text about how scanning works

### Backend:
- `convex/qrCodes.ts`: generateMerchantQR action (generate QR image, store in file storage)
- qrCodeStorageId field on merchants table

## Acceptance Criteria
- [x] QR code generated for each merchant (on demand or at registration)
- [x] QR encodes deep link to create invoice at that merchant
- [x] "Mon QR Code" card on merchant dashboard
- [x] Full-screen QR code view with share and print buttons
- [x] Share via system share sheet works
- [x] QR code stored in Convex file storage

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: QR Code section
- Merchant dashboard: `app/app/(merchant)/(dashboard)/`
- QR generation library: need to add (react-native-qrcode-svg or similar)

## Checklist
- [x] Step 1: Add `qrCodeStorageId` field to merchants schema and merchant registration defaults
- [x] Step 2: Implement `convex/qrCodes.ts` action to generate and persist merchant QR image in Convex storage
- [x] Step 3: Expose QR image URL + deep link from merchant profile query
- [x] Step 4: Add merchant dashboard "Mon QR Code" card that navigates to QR detail screen
- [x] Step 5: Build QR detail screen with explanation, QR preview, share action, and print action
- [x] Step 6: Add i18n strings for QR card, screen copy, and action feedback
- [x] Step 7: Run TypeScript + lint checks and finalize task metadata for review

## Review Notes

## Agent Log
### 2026-03-07 — Start
- Picked task 020 as the next eligible `todo` task (no `in_progress` tasks).
- Set task status to `in_progress`, assigned branch `task/020-merchant-qr-code`, and rewrote checklist into smaller implementation steps.

### 2026-03-07 — Implementation Complete
- Added `qrCodeStorageId` to merchant schema and registration defaults.
- Implemented QR generation backend:
  - `convex/qrCodes.ts` public query/action for fetching and generating merchant QR codes.
  - `convex/qrCodesInternal.ts` internal query/mutation for merchant auth lookup and storage patching.
  - QR content deep link: `massarif://merchant/{merchantId}/create-invoice`.
  - Generated QR image is persisted in Convex storage and old QR assets are cleaned up on regenerate.
- Exposed `qrCodeUrl` and `qrDeepLink` in `merchants.getMyProfile`.
- Built merchant UI:
  - `components/merchant/MerchantQrCard.tsx`
  - Dashboard card entry in `app/(merchant)/(dashboard)/index.tsx`
  - New full-screen route `app/(merchant)/(dashboard)/qr-code.tsx` with generate, share, and print actions.
- Added FR/EN/AR translation keys for all QR-related copy.
- Validation:
  - `cd app && npx tsc --noEmit` passed.
  - `cd app && npx expo lint` passed with one pre-existing warning in `app/(auth)/login.tsx` (`react-hooks/exhaustive-deps`).
  - `npx convex codegen` could not complete in this environment because Convex CLI crashes on a blocked telemetry DNS lookup (`o1192621.ingest.sentry.io`), so `_generated/api.d.ts` was updated manually for the new `qrCodes` modules in this run.
