---
id: "021"
title: "Invoice templates for merchants"
status: review
priority: medium
created: 2026-03-06
updated: 2026-03-07
assigned: codex
branch: task/021-invoice-templates
pr: null
attempts: 0
depends_on: []
progress: 100
---

## Description

Merchants can save invoice templates (e.g., "Pack Medicaments Standard") and reuse them to quickly create invoices with pre-filled fields.

### Features:
- Create template from invoice creation form ("Sauvegarder comme modele" toggle)
- Template picker on invoice creation ("Utiliser un modele" button → bottom sheet)
- Template management (list, edit, delete)
- Max 20 templates per merchant
- Usage count tracked per template

### Schema:
New `invoiceTemplates` table with: merchantId, name, description, amount, currency, items, category, usageCount, isActive

## Acceptance Criteria
- [x] invoiceTemplates table in Convex schema
- [x] CRUD functions for templates (create, list, update, soft delete)
- [x] "Sauvegarder comme modele" toggle on invoice creation form
- [x] "Utiliser un modele" button opens template picker bottom sheet
- [x] Selecting template pre-fills all invoice fields
- [x] Template management screen (list, edit, delete)
- [x] Max 20 templates enforced
- [x] Usage count incremented when template is used
- [x] templateId field added to invoices table

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Invoice Templates section
- Invoice creation: `app/app/(merchant)/(invoices)/`
- Schema: PHASE2_IMPLEMENTATION_PLAN.md invoiceTemplates table

## Checklist
- [x] Step 1: Add invoiceTemplates table to schema.ts
- [x] Step 2: Add templateId field to invoices table
- [x] Step 3: Create convex/invoiceTemplates.ts with CRUD functions
- [x] Step 4: Add createInvoiceFromTemplate mutation
- [x] Step 5: Add "Sauvegarder comme modele" toggle to invoice creation form
- [x] Step 6: Build template picker bottom sheet component
- [x] Step 7: Add "Utiliser un modele" button to invoice creation
- [x] Step 8: Build template management screen (list, edit, delete)
- [x] Step 9: Enforce max 20 templates limit
- [x] Step 10: Test create template → use template → create invoice flow

## Review Notes

## Agent Log
- 2026-03-07: Implemented invoice template schema + CRUD backend, added template-linked invoice creation (`templateId` and `createInvoiceFromTemplate`), wired template save/use in merchant invoice creation, added bottom-sheet picker and template management screen (list/edit/delete), and added FR/EN/AR i18n keys for the new flow. Verified with `npx tsc --noEmit` and `npx expo lint` (existing unrelated warning remains in `app/(auth)/login.tsx`). `npx convex codegen` could not run in this environment due blocked network fetch, so frontend usage is temporarily typed through a safe API-cast fallback.
