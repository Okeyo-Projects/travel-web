---
id: "022"
title: "Payer merchant favorites"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Payers can favorite merchants for quick access. Favorites appear first in the merchant directory and have a dedicated filter tab.

### Features:
- Heart icon on each MerchantCard (outline = not, filled = favorited)
- "Favoris" filter tab in category chips
- Favorites appear at top when "Tous" is selected
- Max 50 favorites per payer

### Schema:
New `favorites` table with: payerId, merchantId, createdAt

## Acceptance Criteria
- [ ] favorites table in Convex schema
- [ ] Toggle favorite function (add/remove)
- [ ] Heart icon on MerchantCard (filled/outline state)
- [ ] "Favoris" tab in merchant directory category filter
- [ ] Favorites appear first when no filter active
- [ ] Max 50 favorites enforced
- [ ] Optimistic UI update on toggle

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Favorites section
- Merchant directory: `app/app/(payer)/(merchants)/`
- MerchantCard: `app/components/merchant/MerchantCard.tsx`

## Checklist
- [ ] Step 1: Add favorites table to schema.ts
- [ ] Step 2: Create convex/favorites.ts (toggle, list, isFavorite)
- [ ] Step 3: Create useFavorites hook
- [ ] Step 4: Add heart icon to MerchantCard
- [ ] Step 5: Add "Favoris" filter tab to merchant directory
- [ ] Step 6: Sort favorites to top when "Tous" selected
- [ ] Step 7: Enforce max 50 limit
- [ ] Step 8: Test toggle, filter, and display

## Review Notes

## Agent Log
