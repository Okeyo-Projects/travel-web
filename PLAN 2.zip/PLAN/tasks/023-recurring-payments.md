---
id: "023"
title: "Recurring payments (schema, backend, cron, UI)"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Payers can set up recurring payments for regular invoices (e.g., monthly medicine supply). Only saved card payment methods can be used (not mobile money).

### Features:
- Recurring payments list screen
- Create recurring payment flow (select merchant, beneficiary, amount, frequency, payment method)
- Pause/resume/cancel actions
- Hourly cron job to execute due payments
- Failure handling (retry once after 24h, pause after 3 failures)

### Business Rules:
- Only saved cards (Stripe SetupIntent) — mobile money requires user confirmation each time
- Each execution creates a real invoice (merchant sees it as normal)
- Fees calculated at execution time (not setup time)
- 3 consecutive failures → auto-pause + notify payer

### Schema:
New `recurringPayments` table with: payerId, merchantId, beneficiaryId, amount, currency, frequency, dayOfMonth, dayOfWeek, nextExecutionAt, status, failureCount, etc.

## Acceptance Criteria
- [ ] recurringPayments table in Convex schema
- [ ] CRUD functions (create, list, pause, resume, cancel)
- [ ] Execute action creates invoice and processes payment
- [ ] Cron job runs hourly to process due payments
- [ ] Failure handling: retry after 24h, pause after 3 failures
- [ ] Recurring payments list screen in payer profile
- [ ] Create recurring payment flow (multi-step form)
- [ ] Pause/resume/cancel UI actions
- [ ] Summary on payer home ("Next payment in X days")
- [ ] New fields on invoices and transactions (recurringPaymentId)

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Recurring Payments section (full specification)
- Stripe saved cards: SetupIntent flow (may need to implement)
- Crons: `app/convex/crons.ts`
- Payment flow: `app/hooks/usePayment.ts`

## Checklist
- [ ] Step 1: Add recurringPayments table to schema.ts
- [ ] Step 2: Add recurringPaymentId to invoices and transactions tables
- [ ] Step 3: Create convex/recurringPayments.ts with create mutation
- [ ] Step 4: Add list, pause, resume, cancel mutations
- [ ] Step 5: Add execute action (create invoice, charge saved card)
- [ ] Step 6: Add hourly cron job to crons.ts
- [ ] Step 7: Implement failure handling (retry, pause after 3)
- [ ] Step 8: Build recurring payments list screen
- [ ] Step 9: Build create recurring payment flow
- [ ] Step 10: Build pause/resume/cancel action UI
- [ ] Step 11: Add "next payment" summary to payer home
- [ ] Step 12: Test full lifecycle: create → execute → fail → retry → pause

## Review Notes

## Agent Log
