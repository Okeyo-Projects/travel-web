---
id: "024"
title: "Receipt PDF generation and download"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Generate PDF receipts for completed transactions. Payers can view and download receipts from the transaction history.

### Receipt Content:
- Transaction ID, date
- Payer name and info
- Merchant name and info
- Beneficiary name
- Amount, fee breakdown
- Payment method
- Exchange rate (if applicable)
- Massarif logo and branding

### Features:
- Receipt view screen with full details
- "Telecharger PDF" button
- "Partager" button (share via system share sheet)
- Download icon on each transaction in history

## Acceptance Criteria
- [ ] convex/receipts.ts with generate action (creates PDF, stores in file storage)
- [ ] receiptStorageId field on transactions table
- [ ] Receipt view screen with all transaction details
- [ ] PDF download button works (fetches from Convex storage)
- [ ] Share button opens system share sheet
- [ ] Download icon on transaction history rows
- [ ] PDF is professional-looking with Massarif branding

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Receipt Generation section
- Transaction history: `app/app/(payer)/(history)/`
- PDF generation: use a Convex action with a PDF library (e.g., @react-pdf/renderer for Node, or jsPDF)
- File storage: Convex file storage

## Checklist
- [ ] Step 1: Add receiptStorageId field to transactions table
- [ ] Step 2: Create convex/receipts.ts with generate action
- [ ] Step 3: Design receipt PDF template
- [ ] Step 4: Build receipt view screen
- [ ] Step 5: Add download PDF button
- [ ] Step 6: Add share button
- [ ] Step 7: Add download icon to transaction history list
- [ ] Step 8: Test PDF generation and download

## Review Notes

## Agent Log
