---
id: "025"
title: "Moov Money payment integration"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Integrate Moov Money (Moov Africa Chad) as the second mobile money payment provider, expanding merchant payout options.

### Integration Pattern:
Same as Airtel Money — STK push to user's Moov wallet, webhook callback for status.

### Backend:
- `convex/payments/moovMoney.ts`: initiatePayment action, handleCallback httpAction, checkStatus action
- HTTP route: POST `/webhooks/moov-money`
- Fee config: 3.5%, min 150 FCFA, max 30,000 FCFA, bearer: payer

### Frontend:
- Add "Moov Money" option to payment method selector
- Moov Money phone number input
- Same status polling pattern as Airtel Money

## Acceptance Criteria
- [ ] convex/payments/moovMoney.ts with initiatePayment, handleCallback, checkStatus
- [ ] Webhook endpoint registered in http.ts
- [ ] Fee config added for moov_money payment method
- [ ] Payment method selector includes Moov Money option
- [ ] Payment flow works end-to-end (initiate → confirm → callback → complete)
- [ ] Moov Money available as merchant payout method
- [ ] Error handling for failed payments

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Moov Money Integration section
- Existing pattern: `app/convex/payments/airtelMoney.ts`
- Payment UI: `app/components/payment/`
- HTTP routes: `app/convex/http.ts`

## Checklist
- [ ] Step 1: Create convex/payments/moovMoney.ts with initiatePayment action
- [ ] Step 2: Add handleCallback httpAction
- [ ] Step 3: Add checkStatus action (polling fallback)
- [ ] Step 4: Register webhook route in http.ts
- [ ] Step 5: Add Moov Money fee config to seed data
- [ ] Step 6: Add Moov Money to payment method selector UI
- [ ] Step 7: Add Moov Money as payout method option for merchants
- [ ] Step 8: Update types/index.ts with moov_money types
- [ ] Step 9: Test payment flow end-to-end

## Review Notes

## Agent Log
