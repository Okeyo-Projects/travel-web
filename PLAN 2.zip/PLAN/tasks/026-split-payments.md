---
id: "026"
title: "Split payments / invoice crowdfunding"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Enable payers to split an invoice among multiple contributors (e.g., family crowdfunding for medical bills). Contributors pay via a shared web link — no app needed.

### Flow:
1. Payer creates split payment for an invoice
2. Adds contributors (name + phone/email + amount or equal split)
3. Generates share link (WhatsApp/SMS/copy)
4. Contributors open link → minimal web page → Stripe checkout
5. When fully funded → invoice auto-paid to merchant

### Business Rules:
- Only invoice creator or linked payer can initiate
- Contributors don't need the app (web Stripe checkout)
- Each contribution = separate transaction
- Auto-complete when amountCollected >= totalAmount
- Expire after 14 days if not fully funded → auto-refund contributors
- Minimum contribution: 1,000 FCFA

### Schema:
New `splitPayments` table with contributions array, shareLink, shareCode, status

## Acceptance Criteria
- [ ] splitPayments table in Convex schema
- [ ] Create, contribute, checkAndFinalize, listForPayer functions
- [ ] Split payment creation UI on invoice detail
- [ ] Add contributors form (name, email/phone, amount)
- [ ] Share link generation (WhatsApp, SMS, copy)
- [ ] Web landing page (`massarif.app/split/{code}`) with Stripe checkout
- [ ] Auto-finalization when fully funded
- [ ] 14-day expiry with auto-refund
- [ ] Contributor status tracking (pledged/paid/failed)

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Split Payments section
- Schema: PHASE2_IMPLEMENTATION_PLAN.md splitPayments table
- Web page: separate mini Vite project (like beneficiary page)

## Checklist
- [ ] Step 1: Add splitPayments table to schema.ts
- [ ] Step 2: Add splitPaymentId to invoices and transactions tables
- [ ] Step 3: Create convex/splitPayments.ts with create mutation
- [ ] Step 4: Add getByShareCode query (public)
- [ ] Step 5: Add contribute action (process payment, update totals)
- [ ] Step 6: Add checkAndFinalize mutation
- [ ] Step 7: Add listForPayer query
- [ ] Step 8: Build split payment creation UI (invoice detail screen)
- [ ] Step 9: Build contributor form
- [ ] Step 10: Build share link generation + share sheet
- [ ] Step 11: Build web landing page with Stripe checkout
- [ ] Step 12: Add 14-day expiry cron + auto-refund logic
- [ ] Step 13: Test full flow: create → share → contribute → finalize

## Review Notes

## Agent Log
