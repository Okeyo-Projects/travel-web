---
id: "027"
title: "Notification preferences and WhatsApp notifications"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Add per-user notification preferences (channel and event toggles) and WhatsApp Business API integration for higher engagement.

### Notification Channels:
- Push (FCM) — existing
- SMS (Twilio) — existing
- Email (Resend) — existing
- WhatsApp (Twilio WhatsApp Business API) — new

### Channel Priority: WhatsApp > Push > SMS > Email

### Preferences Screen:
- Channel toggles: Push, Email, SMS, WhatsApp
- Per-event toggles: invoiceCreated, invoicePaid, invoiceDelivered, invoiceExpired, paymentFailed, recurringPaymentDue, splitPaymentContribution, promotions
- WhatsApp number input (if different from primary)

### Schema:
New `notificationPreferences` table

## Acceptance Criteria
- [ ] notificationPreferences table in Convex schema
- [ ] Get/update preferences functions
- [ ] Notification preferences screen in payer profile
- [ ] Channel toggles work and persist
- [ ] Per-event toggles work and persist
- [ ] WhatsApp number input (optional)
- [ ] Notification sending respects user preferences
- [ ] WhatsApp Business API integration (Twilio)
- [ ] Channel priority: WhatsApp > Push > SMS > Email

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Notification Preferences section
- Existing: `app/convex/notifications.ts`
- Twilio: already integrated for SMS
- Profile settings: `app/app/(payer)/(profile)/settings.tsx`

## Checklist
- [ ] Step 1: Add notificationPreferences table to schema.ts
- [ ] Step 2: Create convex/notificationPreferences.ts (get, update)
- [ ] Step 3: Update notification sending to check preferences
- [ ] Step 4: Add WhatsApp sending via Twilio WhatsApp API
- [ ] Step 5: Implement channel priority logic
- [ ] Step 6: Build notification preferences screen
- [ ] Step 7: Add WhatsApp number input field
- [ ] Step 8: Test preferences affect notification delivery

## Review Notes

## Agent Log
