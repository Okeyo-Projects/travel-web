---
id: "028"
title: "Organizations: schema, registration, verification, member management"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: ["016"]
progress: 0
---

## Description

Build the organization system backend and registration flow. Organizations (NGOs, community associations, etc.) can register, get verified, and manage members.

### Organization Types:
- NGO, Community association, Religious, Education, Healthcare, Individual fundraiser, Other

### Schema:
New `organizations` table with: name, slug, description, type, countryCode, contact info, verification status, members array, stats

### Registration Flow (3 steps):
1. Personal info (link existing payer account or create new)
2. Organization info (name, type, country, description, logo, cover image)
3. Verification documents (registration certificate, ID, etc.)

### User Role Update:
- Add "organization" to UserRole type
- Users can be both payer AND organization member (dual role)
- organizationId field on users table

## Acceptance Criteria
- [ ] organizations table in Convex schema
- [ ] User role updated to include "organization"
- [ ] organizationId field on users table
- [ ] Register mutation creates org + updates user role
- [ ] Member management (add, remove, role assignment)
- [ ] Organization profile CRUD
- [ ] Public listing of verified organizations
- [ ] 3-step registration flow screens
- [ ] Verification document upload
- [ ] Admin verification queue (in admin panel)

## Context
- PHASE2_MEDIA_AND_CAMPAIGNS.md: Organizations section (complete specification)
- Media system needed for logo/cover uploads (task 016)
- Auth: `app/convex/auth.ts`, `app/stores/authStore.ts`

## Checklist
- [ ] Step 1: Add organizations table to schema.ts
- [ ] Step 2: Update users table (add "organization" role, organizationId field)
- [ ] Step 3: Update types/index.ts with Organization types
- [ ] Step 4: Create convex/organizations.ts with register mutation
- [ ] Step 5: Add getById, getBySlug, update, listPublic queries
- [ ] Step 6: Add addMember, removeMember mutations
- [ ] Step 7: Add getMyOrganization, getDashboard queries
- [ ] Step 8: Add admin verify, reject, suspend mutations
- [ ] Step 9: Build register-organization screen (3 steps)
- [ ] Step 10: Add organization verification to admin panel
- [ ] Step 11: Handle dual role (payer + organization member)
- [ ] Step 12: Test registration → verification → member management

## Review Notes

## Agent Log
