---
id: "029"
title: "Campaigns: schema, CRUD, contributions, spending"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: ["028"]
progress: 0
---

## Description

Build the campaign system backend: campaign CRUD, contribution processing, campaign invoices (spending), and updates.

### Key Differentiator:
Money goes to campaign escrow → invoices paid directly to merchants. Every FCFA is traceable. This is NOT generic crowdfunding — it's transparent, merchant-directed spending.

### Campaign Lifecycle:
draft → active (needs admin approval if public) → goal_reached → completed → closed

### Contributions:
- Minimum: configurable per campaign (default 500 FCFA)
- Maximum single: 500,000 FCFA
- Anonymous allowed (tracked internally)
- Same fee engine as regular payments (3.5% on contributor)

### Campaign Invoices (Spending):
- Org creates invoices at LINKED merchants only
- Amount deducted from campaign amountAvailable
- Merchants see them as normal invoices
- Full delivery confirmation flow

### New Tables:
- campaigns, contributions, campaignUpdates, campaignInvoices

## Acceptance Criteria
- [ ] campaigns table in Convex schema
- [ ] contributions table in Convex schema
- [ ] campaignUpdates table in Convex schema
- [ ] campaignInvoices table in Convex schema
- [ ] Campaign CRUD (create, update, publish, pause, resume, complete, close)
- [ ] Contribution processing (create, createAnonymous, refund)
- [ ] Campaign invoice creation (spend from campaign funds)
- [ ] Campaign updates posting
- [ ] Goal tracking (auto-update status on goal reached)
- [ ] Public queries (listPublic, getBySlug, getByShareCode)
- [ ] Admin moderation (approve, reject, feature)
- [ ] 14-day auto-close for one-time campaigns after goal reached
- [ ] Cancellation with proportional refund

## Context
- PHASE2_MEDIA_AND_CAMPAIGNS.md: Campaigns section (complete specification)
- Fee engine: `app/convex/fees.ts`
- Invoice system: `app/convex/invoices.ts`
- Organizations: task 028

## Checklist
- [ ] Step 1: Add campaigns table to schema.ts
- [ ] Step 2: Add contributions table to schema.ts
- [ ] Step 3: Add campaignUpdates table to schema.ts
- [ ] Step 4: Add campaignInvoices table to schema.ts
- [ ] Step 5: Add campaignId and fundingSource to invoices table
- [ ] Step 6: Create convex/campaigns.ts with create, update, publish mutations
- [ ] Step 7: Add pause, resume, complete, close mutations
- [ ] Step 8: Add public queries (listPublic, getBySlug, getByShareCode)
- [ ] Step 9: Add getContributionStats query
- [ ] Step 10: Add createInvoiceFromCampaign mutation
- [ ] Step 11: Add admin moderation mutations (approve, reject, feature)
- [ ] Step 12: Create convex/contributions.ts with create, createAnonymous actions
- [ ] Step 13: Add listForCampaign, listForPayer queries
- [ ] Step 14: Add refund action
- [ ] Step 15: Create convex/campaignUpdates.ts (create, list, delete)
- [ ] Step 16: Create convex/campaignInvoices.ts (create, list, markDelivered)
- [ ] Step 17: Add campaign types to types/index.ts
- [ ] Step 18: Test full flow: create → publish → contribute → spend → update

## Review Notes

## Agent Log
