---
id: "030"
title: "Campaigns UI: discover feed, campaign cards, detail screen"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: ["029", "017"]
progress: 0
---

## Description

Build the payer-facing campaign discovery experience: new "Decouvrir" tab, campaign cards with cover images, campaign detail screen with tabs.

### New Payer Tab: Decouvrir
Position: between Accueil and Commercants. Icon: compass or heart-hands.

### Discover Feed:
- Featured campaign banner (full-width, overlay gradient, cover image)
- Category filter chips (horizontal scroll): Tout, Sante, Alimentation, Education, Urgence, Communaute
- Campaign card list (vertical scroll)

### Campaign Card Design:
- Cover image (16:9 aspect ratio, rounded top)
- Organization name with small logo
- Campaign title (bold, 2 lines max)
- Progress bar (teal on gray)
- Stats: amount raised / goal, contributor count
- Category tag, time remaining
- "Contribuer" button

### Campaign Detail Screen:
- Cover image (full-width, 200px, gradient overlay)
- Organization badge (overlapping image bottom)
- Stats row: Collectes, Donateurs, Restants
- Progress bar with percentage
- Suggested contribution buttons (1000, 5000, 10000, 25000, Autre)
- Tabs: Description, Depenses (spending transparency), Donateurs, Actualites
- Linked merchants section
- Share button

## Acceptance Criteria
- [ ] New "Decouvrir" tab in payer navigation
- [ ] Featured campaign banner at top
- [ ] Category filter chips filter campaigns
- [ ] Campaign card component with cover image and progress
- [ ] Campaign detail screen with all 4 tabs
- [ ] Description tab shows full text
- [ ] Depenses tab shows invoices funded by campaign (transparency)
- [ ] Donateurs tab shows contributors (respecting anonymity)
- [ ] Actualites tab shows organization updates
- [ ] Share button works (WhatsApp, SMS, copy)
- [ ] Empty state when no campaigns

## Context
- PHASE2_MEDIA_AND_CAMPAIGNS.md: Discover Feed, Campaign Card, Campaign Detail sections
- Navigation: `app/app/(payer)/` — add new (discover) group
- Media components from task 017

## Checklist
- [ ] Step 1: Add (discover) route group to payer navigation
- [ ] Step 2: Update payer tab bar with "Decouvrir" tab
- [ ] Step 3: Build CampaignCard component
- [ ] Step 4: Build featured campaign banner component
- [ ] Step 5: Build category filter chips for campaigns
- [ ] Step 6: Build discover feed screen
- [ ] Step 7: Build campaign detail screen header (cover, org badge, stats)
- [ ] Step 8: Build description tab
- [ ] Step 9: Build spending/depenses tab (invoice list from campaign)
- [ ] Step 10: Build contributors/donateurs tab
- [ ] Step 11: Build updates/actualites tab
- [ ] Step 12: Add linked merchants section
- [ ] Step 13: Add share button functionality
- [ ] Step 14: Add empty state
- [ ] Step 15: Test full discovery → detail → share flow

## Review Notes

## Agent Log
