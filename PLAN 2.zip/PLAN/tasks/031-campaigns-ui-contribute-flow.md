---
id: "031"
title: "Campaigns UI: contribution flow, success screen, web page"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: ["029", "030"]
progress: 0
---

## Description

Build the campaign contribution flow: amount selection, payment, success screen, and the shareable web page for non-app users.

### Contribute Flow:
1. Campaign summary card (compact)
2. Quick amount buttons: 1000, 5000, 10000, 25000 FCFA
3. Custom amount input with EUR equivalent
4. Anonymous toggle, optional message
5. Payment method selector (same as invoice payment)
6. Fee breakdown
7. "Contribuer {amount}" button
8. Success screen with share prompt

### Campaign Web Page (`massarif.app/c/{slug}`):
- Public campaign page for sharing outside the app
- Campaign details, progress, contributor list
- "Contribuer" button → Stripe checkout (no app needed)
- Must work well on mobile browsers

## Acceptance Criteria
- [ ] Contribute screen with quick amount buttons and custom input
- [ ] EUR equivalent display
- [ ] Anonymous toggle and message input
- [ ] Payment method selector
- [ ] Fee breakdown display
- [ ] Payment processing (Stripe/mobile money)
- [ ] Success screen with share prompt
- [ ] Campaign web page (massarif.app/c/{slug}) works
- [ ] Web Stripe checkout for non-app contributions
- [ ] Success page with app download link

## Context
- PHASE2_MEDIA_AND_CAMPAIGNS.md: Contribute Flow, Campaign Web Page sections
- Payment components: `app/components/payment/`
- Payment hook: `app/hooks/usePayment.ts`

## Checklist
- [ ] Step 1: Build contribute screen (amount selection, options)
- [ ] Step 2: Integrate payment method selector
- [ ] Step 3: Build fee breakdown component
- [ ] Step 4: Process contribution payment
- [ ] Step 5: Build success screen
- [ ] Step 6: Create campaign web page project (Vite)
- [ ] Step 7: Build web page with campaign details and progress
- [ ] Step 8: Integrate Stripe checkout on web page
- [ ] Step 9: Build web success page with app download link
- [ ] Step 10: Test full flow: app contribute + web contribute

## Review Notes

## Agent Log
