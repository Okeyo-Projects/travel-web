---
id: "032"
title: "Organization dashboard and campaign management screens"
status: todo
priority: medium
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: ["028", "029"]
progress: 0
---

## Description

Build the organization-facing screens: dashboard, campaign creation (4-step form), campaign management with tabs.

### Organization Navigation (new tab group):
```
Tableau de bord | Campagnes | Factures | Profil
```

### Dashboard:
- Stats cards: Total collecte, Contributeurs, Depense
- Active campaigns list (compact cards with progress)
- Recent contributions feed
- "Creer une campagne" FAB

### Create Campaign (4 steps):
1. Informations — title, descriptions, category, cover/gallery images
2. Objectif et duree — type, goal, dates, suggested amounts, minimum
3. Commercants — select linked merchants, optional allocation
4. Parametres — visibility, anonymous toggle, sharing

### Campaign Management:
- Tabs: Apercu (editable), Contributions (with export), Depenses ("Creer une facture" button), Actualites (post updates)
- "Creer une facture" flow: select merchant, amount (max available), description, photos → creates invoice
- Campaign actions: pause, resume, close, share

### Role Switching:
Users who are both payer and org member can switch roles in profile.

## Acceptance Criteria
- [ ] Organization tab navigation works
- [ ] Dashboard shows stats, campaigns, recent contributions
- [ ] Campaign creation 4-step form works end-to-end
- [ ] Campaign management with 4 tabs
- [ ] Create invoice from campaign funds works
- [ ] Post campaign updates with photos works
- [ ] Role switching between payer and organization
- [ ] FAB button creates new campaign
- [ ] Public campaigns show "pending moderation" message

## Context
- PHASE2_MEDIA_AND_CAMPAIGNS.md: Organization screens section
- Navigation: add `app/(organization)/` route group
- Auth store: needs role switching support

## Checklist
- [ ] Step 1: Create (organization) route group with tab navigation
- [ ] Step 2: Build organization dashboard screen
- [ ] Step 3: Build campaign creation step 1 (information)
- [ ] Step 4: Build campaign creation step 2 (goal and duration)
- [ ] Step 5: Build campaign creation step 3 (merchants)
- [ ] Step 6: Build campaign creation step 4 (settings)
- [ ] Step 7: Build campaign creation review and submit
- [ ] Step 8: Build campaign management screen with tabs
- [ ] Step 9: Build "create invoice from campaign" flow
- [ ] Step 10: Build post update functionality
- [ ] Step 11: Add role switching to profile
- [ ] Step 12: Update auth store for role switching
- [ ] Step 13: Test full org flow: dashboard → create campaign → manage → spend

## Review Notes

## Agent Log
