---
id: "034"
title: "Multi-currency exchange rate engine"
status: todo
priority: low
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Build the exchange rate engine: rate caching, periodic refresh, manual overrides, and display in payment flows.

### Exchange Rates Table:
- fromCurrency, toCurrency, baseRate, spreadPercentage, displayedRate
- Source: peg_fixed (XAF/EUR), api_xe (market rates), manual
- Refresh every 6 hours via cron
- For XAF/EUR: fixed peg (655.957), only refresh spread config
- For non-pegged currencies: fetch market rate + apply spread

### Features:
- getRate query for payment flow
- updateRates cron action (every 6 hours)
- setManualRate admin mutation (override)
- Rate display in payment confirmation screen

## Acceptance Criteria
- [ ] exchangeRates table in Convex schema
- [ ] getRate query returns current rate for any pair
- [ ] Cron refreshes rates every 6 hours
- [ ] XAF/EUR uses fixed peg with configurable spread
- [ ] Admin can set manual rate override
- [ ] Payment flow shows exchange rate when applicable
- [ ] Rate expiry handling (stale rates flagged)

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Exchange Rates section
- Config: `app/constants/config.ts` (existing xafEurPegRate)
- Admin panel: task 015 (fee/country config)

## Checklist
- [ ] Step 1: Add exchangeRates table to schema.ts
- [ ] Step 2: Create convex/exchangeRates.ts with getRate query
- [ ] Step 3: Add updateRates action (fetch from external API)
- [ ] Step 4: Add cron job (every 6 hours)
- [ ] Step 5: Add setManualRate admin mutation
- [ ] Step 6: Update payment flow to show exchange rate
- [ ] Step 7: Test rate refresh and display

## Review Notes

## Agent Log
