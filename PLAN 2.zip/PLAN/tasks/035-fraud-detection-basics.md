---
id: "035"
title: "Basic fraud detection rules and admin fraud queue"
status: todo
priority: low
created: 2026-03-06
updated: 2026-03-06
assigned: codex
branch: null
pr: null
attempts: 0
depends_on: []
progress: 0
---

## Description

Implement basic fraud detection rules that flag suspicious transactions for admin review. Flagged transactions proceed but appear in the admin fraud queue.

### Detection Rules:
1. Single transaction > 500,000 FCFA
2. Payer making > 10 transactions in 1 hour
3. Merchant receiving > 20 payments in 1 hour
4. New account (< 7 days) with transaction > 100,000 FCFA

### Admin Fraud Queue:
- List of flagged transactions with reason
- One-click suspend account action
- Dismiss flag action (false positive)

### Implementation:
- Check rules in transaction creation flow
- Flag but don't block (transactions still proceed)
- Add isFlagged, flagReason fields to transactions

## Acceptance Criteria
- [ ] All 4 fraud rules implemented and checked on transaction creation
- [ ] Flagged transactions visible in admin fraud queue
- [ ] Admin can suspend accounts from fraud queue
- [ ] Admin can dismiss false positives
- [ ] Transactions are NOT blocked, only flagged
- [ ] Flag reason recorded

## Context
- PHASE2_IMPLEMENTATION_PLAN.md: Fraud Detection section
- Transactions: `app/convex/transactions.ts`
- Admin panel: task 010

## Checklist
- [ ] Step 1: Add isFlagged, flagReason fields to transactions table
- [ ] Step 2: Implement rule 1 (amount > 500,000)
- [ ] Step 3: Implement rule 2 (payer velocity > 10/hour)
- [ ] Step 4: Implement rule 3 (merchant velocity > 20/hour)
- [ ] Step 5: Implement rule 4 (new account + high value)
- [ ] Step 6: Build admin fraud queue page
- [ ] Step 7: Add suspend/dismiss actions
- [ ] Step 8: Test each rule fires correctly

## Review Notes

## Agent Log
